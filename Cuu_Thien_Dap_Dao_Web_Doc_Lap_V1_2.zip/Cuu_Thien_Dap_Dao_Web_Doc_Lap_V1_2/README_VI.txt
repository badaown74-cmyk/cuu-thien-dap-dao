CỬU THIÊN ĐẠP ĐẠO — WEB ĐỘC LẬP V1.2 (PWA)

Gói này bổ sung manifest, biểu tượng ứng dụng, Service Worker và đăng ký PWA vào bản V1.1. Mã gameplay gốc được giữ nguyên; chỉ thêm phần metadata PWA và đăng ký Service Worker.

CÁCH TRIỂN KHAI
1. Tải và giải nén toàn bộ ZIP, giữ nguyên cấu trúc thư mục.
2. Đưa toàn bộ nội dung thư mục lên một dịch vụ hosting web tĩnh có HTTPS. Không mở index.html trực tiếp từ ứng dụng Tệp; Service Worker/PWA cần HTTPS (hoặc localhost).
3. Truy cập URL HTTPS trên Safari iPhone.
4. Chọn Chia sẻ > Thêm vào Màn hình chính. Mở biểu tượng để chạy chế độ standalone.

LƯU Ý
- PWA không đồng nghĩa tự động đồng bộ giữa Safari và biểu tượng màn hình chính. Hãy dùng chức năng xuất file sao lưu trong game trước khi chuyển môi trường.
- Service Worker cache vỏ ứng dụng và tài nguyên cùng miền. Font Google tải ngoài cần mạng ở lần đầu và có thể không có khi ngoại tuyến.
- Chưa xác nhận gameplay/WebGL/offline trên thiết bị iPhone thực tế. Cần kiểm thử sau khi triển khai HTTPS.
- Không xóa bản Artifact hoặc file V170/V1.1 gốc.
